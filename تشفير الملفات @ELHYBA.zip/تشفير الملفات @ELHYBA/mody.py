import os


class Mody(object):
    ELHYBA = os.environ.get("ELHYBA", "")

